<?php 
$servername = "localhost";
$username = "root";
$pass = "";
$db = "form_submission";

$conn = mysqli_connect($servername, $username, $pass, $db);



?>