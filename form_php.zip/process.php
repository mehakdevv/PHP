<?php  
include('db.php');

if (isset($_POST['submit'])) {
    $schoolName = $_POST['name'];
    $scholarFirst = $_POST['scholar_first'];
    $scholarLast = $_POST['scholar_last'];
    $parentFirst = $_POST['parent_first'];
    $parentLast = $_POST['parent_last'];
    $parentNumber = $_POST['phone'];
    $parentEmail = $_POST['email'];
    $sport = $_POST['sport'];

    $query = "INSERT INTO form_data (id, schoolname, scholarfirst, scholarsecond, parentfirst, parentsecond, parentnumber, parentemail, sport) 
    VALUES ('' ,'$schoolName', '$scholarFirst', '$scholarLast', '$parentFirst', '$parentLast', '$parentEmail', '$sport')";
    $result = mysqli_query($conn, $query);

    if ($result) {
       echo "Data Uploaded to database";
    }else{
        echo "Error " . mysqli_error($conn);
    }
}

?>